import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:hive/hive.dart';
import 'login_page.dart';
import 'register_model.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({Key? key}) : super(key: key);

  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  TextEditingController usernameCon = TextEditingController();
  TextEditingController passwordCon = TextEditingController();

  @override
  void dispose() {
    usernameCon.dispose();
    passwordCon.dispose();
    super.dispose();
  }

  register() async {
    final username = usernameCon.text;
    final password = passwordCon.text;

    if (username.isNotEmpty && password.isNotEmpty) {
      final box = await Hive.openBox<RegisterModel>('registerBox');
      box.put(username, RegisterModel(username: username, password: password));

      Fluttertoast.showToast(
        msg: "Registration successful",
        fontSize: 18,
      );

      Navigator.pop(context); // Go back to the login page after registration
    } else {
      Fluttertoast.showToast(
        msg: "Username and password cannot be empty",
        fontSize: 18,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Register"),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.red,
      ),
      backgroundColor: Color(0xFFF5F5F5),
      body: SingleChildScrollView(
        child: Container(
          constraints: BoxConstraints(
            minHeight: MediaQuery.of(context).size.height,
          ),
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.red, Colors.black],
            ),
          ),
          padding: EdgeInsets.all(24),
          child: Column(
            children: [
              Container(
                child: Text(
                  "Register",
                  style: TextStyle(
                    fontSize: 40,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
              Image.asset("images/marvel.png"),
              SizedBox(height: 14),
              Container(
                child: Column(
                  children: [
                    TextField(
                      controller: usernameCon,
                      decoration: customInputDecoration(
                        label: "Username",
                        icon: Icons.person,
                      ),
                    ),
                    SizedBox(height: 14),
                    TextField(
                      controller: passwordCon,
                      obscureText: true,
                      decoration: customInputDecoration(
                        label: "Password",
                        icon: Icons.lock,
                      ),
                    ),
                    SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      height: 56,
                      child: TextButton(
                        onPressed: () {
                          print("Button Pressed");
                          register();
                        },
                        child: Text(
                          "Register",
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.white,
                          ),
                        ),
                        style: TextButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                          backgroundColor: Colors.red,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

InputDecoration customInputDecoration({required String label, required IconData icon}) {
  return InputDecoration(
    hintText: label,
    hintStyle: TextStyle(
      fontSize: 18,
      color: Colors.black54,
    ),
    prefixIcon: Padding(
      padding: EdgeInsets.only(left: 20, right: 10),
      child: Icon(
        icon,
        color: Colors.black54,
      ),
    ),
    contentPadding: EdgeInsets.fromLTRB(24, 20, 24, 20),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(30),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(30),
    ),
    fillColor: Color(0xFFFCFCFC),
    filled: true,
  );
}