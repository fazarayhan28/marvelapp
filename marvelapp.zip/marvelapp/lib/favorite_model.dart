import 'package:hive/hive.dart';

part 'favorite_model.g.dart';

@HiveType(typeId: 3)
class FavoriteModel extends HiveObject {
  @HiveField(4)
  late String id;

  @HiveField(5)
  late bool isFavorite;

  FavoriteModel({
    required this.id,
    required this.isFavorite,
  });
}