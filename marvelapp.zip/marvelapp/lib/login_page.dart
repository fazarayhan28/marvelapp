import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:mcu_film_wiki/home_screen.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'register_model.dart';
import 'register_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  TextEditingController usernameCon = TextEditingController();
  TextEditingController passwordCon = TextEditingController();

  @override
  void dispose() {
    usernameCon.dispose();
    passwordCon.dispose();
    super.dispose();
  }

  login() async {
    final username = usernameCon.text;
    final password = passwordCon.text;

    if (username.isEmpty || password.isEmpty) {
      Fluttertoast.showToast(
        msg: "Username and password cannot be empty",
        fontSize: 18,
      );
      return;
    }

    final box = await Hive.openBox<RegisterModel>('registerBox');
    final user = box.get(username);

    if (user != null && user.password == password) {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      prefs.setBool('isLoggedIn', true);

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (builder) => HomeScreen(),
        ),
      );
    } else {
      Fluttertoast.showToast(
        msg: "Login failed",
        fontSize: 18,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F5F5),
      appBar: AppBar(
        title: Text("Marvel Cinematic Universe"),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.red,
      ),
      body: SingleChildScrollView(
        child: Container(
          constraints: BoxConstraints(
            minHeight: MediaQuery.of(context).size.height,
          ),
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.red, Colors.black],
            ),
          ),
          padding: EdgeInsets.all(24),
          child: Column(
            children: [
              Container(
                child: Text(
                  "Login",
                  style: TextStyle(
                    fontSize: 40,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 12),
                child: Text(
                  "Login using email and password",
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white,
                  ),
                ),
              ),
              Image.asset("images/marvel.png"),
              SizedBox(height: 14),
              Container(
                child: Column(
                  children: [
                    TextField(
                      controller: usernameCon,
                      decoration: customInputDecoration(
                        label: "Username",
                        icon: Icons.person,
                      ),
                    ),
                    SizedBox(height: 14),
                    TextField(
                      controller: passwordCon,
                      obscureText: true,
                      decoration: customInputDecoration(
                        label: "Password",
                        icon: Icons.lock,
                      ),
                    ),
                    SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      height: 56,
                      child: TextButton(
                        onPressed: () {
                          print("Button Pressed");
                          login();
                        },
                        child: Text(
                          "Login",
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.white,
                          ),
                        ),
                        style: TextButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                          backgroundColor: Colors.red,
                        ),
                      ),
                    ),
                    SizedBox(height: 14),
                    TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => RegisterPage(),
                          ),
                        );
                      },
                      child: Text(
                        "Create an account",
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Move this function outside the _LoginPageState class
InputDecoration customInputDecoration({required String label, required IconData icon}) {
  return InputDecoration(
    hintText: label,
    hintStyle: TextStyle(
      fontSize: 18,
      color: Colors.black54,
    ),
    prefixIcon: Padding(
      padding: EdgeInsets.only(left: 20, right: 10),
      child: Icon(
        icon,
        color: Colors.black54,
      ),
    ),
    contentPadding: EdgeInsets.fromLTRB(24, 20, 24, 20),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(30),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(30),
    ),
    fillColor: Color(0xFFFCFCFC),
    filled: true,
  );
}

// Other code remains unchanged