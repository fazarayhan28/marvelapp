import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mcu_film_wiki/Models/mcu_model.dart';
import 'package:mcu_film_wiki/login_page.dart';
import 'details_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'favorite_model.dart';

class FavoritePage extends StatefulWidget {
  const FavoritePage({Key? key}) : super(key: key);

  @override
  _FavoritePageState createState() => _FavoritePageState();
}

class _FavoritePageState extends State<FavoritePage> {
  var marvelApiUrl = "https://mcuapi.herokuapp.com/api/v1/movies";
  List<McuModels> mcuMoviesList = [];
  List<McuModels> favoriteMcuMovies = [];

  @override
  void initState() {
    getMarvelMovies();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Favorite Page"),
        centerTitle: true,
        backgroundColor: Colors.red,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          // Clear the session using shared preferences
          final SharedPreferences prefs =
          await SharedPreferences.getInstance();
          prefs.remove('isLoggedIn');

          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (builder) => LoginPage(),
            ),
          );
        },
        child: Icon(Icons.logout_rounded),
        backgroundColor: Colors.red,
      ),
      backgroundColor: Colors.grey[900],
      body: SafeArea(
        child: favoriteMcuMovies.isNotEmpty
            ? GridView.builder(
          padding: EdgeInsets.symmetric(horizontal: 15.0, vertical: 15.0),
          itemCount: favoriteMcuMovies.length,
          gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
            maxCrossAxisExtent: 200,
            childAspectRatio: 2 / 3,
            crossAxisSpacing: 15,
            mainAxisSpacing: 10,
          ),
          itemBuilder: (BuildContext context, int index) {
            return GestureDetector(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: favoriteMcuMovies[index].coverUrl != null
                    ? CachedNetworkImage(
                  imageUrl:
                  favoriteMcuMovies[index].coverUrl.toString(),
                  placeholder: (context, url) =>
                      Image.asset('images/place_holder.jpg'),
                )
                    : Image.asset('images/place_holder.jpg'),
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => DetailsScreen(
                        mcuMoviesList: favoriteMcuMovies[index]),
                  ),
                );
              },
            );
          },
        )
            : Center(
          child: Center(
            child: CircularProgressIndicator(color: Colors.white70),
          ),
        ),
      ),
    );
  }

  void getMarvelMovies() async {
    final uri = Uri.parse(marvelApiUrl);

    http.get(uri).then(
          (response) async {
        if (response.statusCode == 200) {
          final responseBody = response.body;
          final decodedData = jsonDecode(responseBody);
          final List marvelData = decodedData['data'];

          for (var i = 0; i < marvelData.length; i++) {
            final mcuMovie =
            McuModels.fromJson(marvelData[i] as Map<String, dynamic>);
            mcuMoviesList.add(mcuMovie);

            // Check if the movie is in favorites and add it to favoriteMcuMovies
            if (await isMovieInFavorites(mcuMovie.id ?? 0)) {
              favoriteMcuMovies.add(mcuMovie);
            }
          }
          setState(() {});
        } else {
          // Handle error
        }
      },
    ).catchError(
          (err) {
        debugPrint('============ $err ==============');
      },
    );
  }


  // Replace this with your actual implementation
  Future<bool> isMovieInFavorites(int movieId) async {
    final favoriteBox = await Hive.openBox<FavoriteModel>('favorites');
    return favoriteBox.containsKey(movieId);
  }
}
