import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mcu_film_wiki/Models/mcu_model.dart';
import 'package:mcu_film_wiki/login_page.dart';
import 'details_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'favorite_page.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  var marvelApiUrl = "https://mcuapi.herokuapp.com/api/v1/movies";
  static List<McuModels> mcuMoviesList = [];

  int _currentIndex = 0;

  @override
  void initState() {
    getMarvelMovies();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Welcome"),
        centerTitle: true,
        backgroundColor: Colors.red,
        actions: [
          IconButton(
            icon: Icon(Icons.favorite),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => FavoritePage(),
                ),
              );
            },
          ),
        ],
      ),

      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          // Clear the session using shared preferences
          final SharedPreferences prefs = await SharedPreferences.getInstance();
          prefs.remove('isLoggedIn');

          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (builder) => LoginPage(),
            ),
          );
        },
        child: Icon(Icons.logout_rounded),
        backgroundColor: Colors.red,
      ),
      backgroundColor: Colors.grey[900],
      body: SafeArea(
        child: mcuMoviesList.isNotEmpty
            ? GridView.builder(
          padding: EdgeInsets.symmetric(horizontal: 15.0, vertical: 15.0),
          itemCount: mcuMoviesList.length,
          gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
            maxCrossAxisExtent: 200,
            childAspectRatio: 2 / 3,
            crossAxisSpacing: 15,
            mainAxisSpacing: 10,
          ),
          itemBuilder: (BuildContext context, int index) {
            return GestureDetector(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: mcuMoviesList[index].coverUrl != null
                    ? CachedNetworkImage(
                  imageUrl:
                  mcuMoviesList[index].coverUrl.toString(),
                  placeholder: (context, url) =>
                      Image.asset('images/place_holder.jpg'),
                )
                    : Image.asset('images/place_holder.jpg'),
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => DetailsScreen(
                        mcuMoviesList: mcuMoviesList[index]),
                  ),
                );
              },
            );
          },
        )
            : Center(
          child: Center(
            child: CircularProgressIndicator(color: Colors.white70),
          ),
        ),
      ),
    );
  }

  void getMarvelMovies() {
    final uri = Uri.parse(marvelApiUrl);
    http.get(uri).then(
          (response) {
        if (response.statusCode == 200) {
          final responseBody = response.body;
          final decodedData = jsonDecode(responseBody);
          final List marvelData = decodedData['data'];
          for (var i = 0; i < marvelData.length; i++) {
            final mcuMovie =
            McuModels.fromJson(marvelData[i] as Map<String, dynamic>);
            mcuMoviesList.add(mcuMovie);
          }
          setState(() {});
        } else {
          // Handle error
        }
      },
    ).catchError(
          (err) {
        debugPrint('============ $err ==============');
      },
    );
  }
}

