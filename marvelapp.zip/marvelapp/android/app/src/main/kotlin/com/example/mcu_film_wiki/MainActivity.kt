package com.example.mcu_film_wiki

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
